import tensorflow as tf
from tensorflow import keras
import pathlib
import numpy as np

data_dir = pathlib.Path('guns')
print(data_dir)

batch_size = 5
img_height = 180
img_width = 180

train_ds = tf.keras.utils.image_dataset_from_directory(
  data_dir,
  validation_split=0.2,
  subset="training",
  seed=123,
  image_size=(img_height, img_width),
  batch_size=batch_size)

class_names = train_ds.class_names


model = keras.models.load_model('test_2')

img = tf.keras.utils.load_img(
    'guns/test/mach2.jpg', target_size=(180, 180)
)
img_array = tf.keras.utils.img_to_array(img)
img_array = tf.expand_dims(img_array, 0) # Create a batch

predictions = model.predict(img_array)
score = tf.nn.softmax(predictions[0])
index = 0

print(
    "1. This image most likely belongs to {} with a {:.2f} percent confidence."
    .format(class_names[np.argmax(score)], 100 * np.max(score))
)

# print('Class: '+class_names[np.argmax(score)])
# print('Numpy argmax score:'+np.argmax(score))
# print('Score:')
# print(score)


max = 0
for idx, val in enumerate(score):
    if val > max:
        max = val
        index = idx

classes = []
for idx, val in enumerate(class_names):
    if idx != np.argmax(score):
        classes.append(val)

score = np.delete(score.numpy(), index, axis=None)
score = tf.constant(score)

print(
    "2. This image most likely belongs to {} with a {:.2f} percent confidence."
    .format(classes[np.argmax(score)], 100 * np.max(score))
)

max = 0
for idx, val in enumerate(score):
    if val > max:
        max = val
        index = idx
classes2 = []
for idx, val in enumerate(classes):
    if idx != np.argmax(score):
        classes2.append(val)
score = np.delete(score.numpy(), index, axis=None)
score = tf.constant(score)


print(
    "3. This image most likely belongs to {} with a {:.2f} percent confidence."
    .format(classes2[np.argmax(score)], 100 * np.max(score))
)